from django.apps import AppConfig


class EmpleadosConfig(AppConfig):
    name = 'Empleados'
